import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Usuario } from './../../model/Usuario';
import { NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-correo',
  templateUrl: './correo.page.html',
  styleUrls: ['./correo.page.scss'],
})
export class CorreoPage implements OnInit {

  public correo: string = '';

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public validarCorreoParaRespuesta(): void{
    const usuario = new Usuario('', '', '', '', '')
    const usuarioEncontrado = usuario.buscarUsuarioPorCorreo(this.correo);
    if(!usuarioEncontrado){
      alert('El correo ingresado no es válido')
    } else {
      alert('Correo válido')
      const navigationExtras: NavigationExtras = {
        state: {
          usuario: usuarioEncontrado
        }
      };
      // Navegamos hacia el Home y enviamos la información extra
      this.router.navigate(['/pregunta'], navigationExtras);
    }
    
    
  }
  ionViewDidEnter() {
    const fechaActual = new Date();
    const horaActual = fechaActual.getHours();
    const minutosActuales = fechaActual.getMinutes();
    const segundosActuales = fechaActual.getSeconds();

    const horaElement = document.getElementById('horaActual');

    if (horaElement) {
      horaElement.textContent = `La hora actual es: ${horaActual}:${minutosActuales}:${segundosActuales}`;
    }
  }
}
