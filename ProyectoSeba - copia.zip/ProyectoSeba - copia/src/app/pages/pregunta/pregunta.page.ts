import { Component, OnInit } from '@angular/core';
import { Usuario } from './../../model/Usuario';
import { Router, NavigationExtras} from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-pregunta',
  templateUrl: './pregunta.page.html',
  styleUrls: ['./pregunta.page.scss'],
})
export class PreguntaPage implements OnInit {

  public usuario: Usuario = new Usuario('', '', '', '', '');  
  public respuesta: string = '';
  public password: string = '';

  constructor(
    private activatedroute: ActivatedRoute
  , private router: Router) {


this.activatedroute.queryParams.subscribe(params => {     
  const navigation = this.router.getCurrentNavigation();
  if (navigation) {
    if (navigation.extras.state) { // Validar que tenga datos extras
      // Si tiene datos extra, se rescatan y se asignan a una propiedad
      this.usuario = navigation.extras.state['usuario'];
    } else {
      this.router.navigate(['/ingreso']);
    }
  } 
});
}
  ngOnInit() {
  }

  public validarRespuestaSecreta(): void {
    if (this.usuario.respuestaSecreta === this.respuesta){
      const navigationExtras: NavigationExtras = {
        state: {
          datoPersonalizado: this.usuario.password
        }};
      this.router.navigate(['/correcto'],navigationExtras);
    } else{
      this.router.navigate(['/incorrecto'])
    }
  }
  ionViewDidEnter() {
    const fechaActual = new Date();
    const horaActual = fechaActual.getHours();
    const minutosActuales = fechaActual.getMinutes();
    const segundosActuales = fechaActual.getSeconds();

    const horaElement = document.getElementById('horaActual');

    if (horaElement) {
      horaElement.textContent = `La hora actual es: ${horaActual}:${minutosActuales}:${segundosActuales}`;
    }
  }
}
