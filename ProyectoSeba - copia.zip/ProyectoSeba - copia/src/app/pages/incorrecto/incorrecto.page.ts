import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incorrecto',
  templateUrl: './incorrecto.page.html',
  styleUrls: ['./incorrecto.page.scss'],
})
export class IncorrectoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  ionViewDidEnter() {
    const fechaActual = new Date();
    const horaActual = fechaActual.getHours();
    const minutosActuales = fechaActual.getMinutes();
    const segundosActuales = fechaActual.getSeconds();

    const horaElement = document.getElementById('horaActual');

    if (horaElement) {
      horaElement.textContent = `La hora actual es: ${horaActual}:${minutosActuales}:${segundosActuales}`;
    }
  }
}
