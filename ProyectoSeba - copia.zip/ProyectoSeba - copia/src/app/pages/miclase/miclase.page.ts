import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-miclase',
  templateUrl: './miclase.page.html',
  styleUrls: ['./miclase.page.scss'],
})
export class MiclasePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
