import { Component, OnInit } from '@angular/core';
import { Usuario } from './../../model/Usuario';
import { Router, NavigationExtras} from '@angular/router';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-correcto',
  templateUrl: './correcto.page.html',
  styleUrls: ['./correcto.page.scss'],
})

export class CorrectoPage implements OnInit {

  datoRecibido: string = '';

  constructor(private route: ActivatedRoute) { 
  }

  ngOnInit() {
    const navigationState = this.route.paramMap.subscribe(params => {
      const state = history.state;
      if (state && state.datoPersonalizado) {
        this.datoRecibido = state.datoPersonalizado;
      }
    });
  }

ionViewDidEnter() {
    const fechaActual = new Date();
    const horaActual = fechaActual.getHours();
    const minutosActuales = fechaActual.getMinutes();
    const segundosActuales = fechaActual.getSeconds();

    const horaElement = document.getElementById('horaActual');

    if (horaElement) {
      horaElement.textContent = `La hora actual es: ${horaActual}:${minutosActuales}:${segundosActuales}`;
    }
  }
  
}
