import { NivelEducacional } from './nivel-educacional';

describe('NivelEducacional', () => {
  it('should create an instance', () => {
    expect(new NivelEducacional()).toBeTruthy();
  });
});
