echo "******************************************"
echo "COMPILAR Y EJECUTAR APLICACION"
echo "******************************************\n\n"


sh _build.sh
sh _run.sh

