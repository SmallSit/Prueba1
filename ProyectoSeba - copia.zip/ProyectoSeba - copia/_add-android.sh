echo "******************************************"
echo "AGREGAR SOPORTE PARA ANDROID"
echo "******************************************\n\n"


ionic capacitor add android
